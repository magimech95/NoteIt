package com.magesh.noteit;

import android.content.Context;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;

public class TasksAdapter extends RecyclerView.Adapter<TasksAdapter.ViewHolder>{
    private static final String TAG = "TasksAdapter : ";
    private Context context;
    private String[] data;

    public TasksAdapter(String[] data) {
        this.data = data;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        context = parent.getContext();
        View v = LayoutInflater.from(context).inflate(R.layout.partial_list_view, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Log.d(TAG, "In onBindViewHolder: " + position);
        holder.taskItem.setText(data[position]);
//        if(position == getItemCount()-1){
//            Log.d(TAG, "Count :" + getItemCount());
//            holder.itemView.findViewById(R.id.partilal_list_add_new).setVisibility(View.VISIBLE);
//        }
    }

    @Override
    public int getItemCount() {
        return (data != null) ? data.length : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        EditText taskItem;
        AppCompatCheckBox taskStatus;
        ImageButton taskRemove;
        public ViewHolder(View itemView) {
            super(itemView);
            taskItem = (EditText) itemView.findViewById(R.id.partilal_list_item);
            taskStatus = (AppCompatCheckBox) itemView.findViewById(R.id.partilal_list_checkbox);
            taskRemove = (ImageButton) itemView.findViewById(R.id.partilal_list_remove);
        }
    }
}
