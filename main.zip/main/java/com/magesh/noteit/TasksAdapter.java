package com.magesh.noteit;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.magesh.noteit.models.Task;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.INPUT_METHOD_SERVICE;

public class TasksAdapter extends RecyclerView.Adapter<TasksAdapter.ViewHolder>{
    private static final String TAG = "TasksAdapter : ";
    private Context context;
    private LinearLayout addNewItemView;
    private List<Task> data;
    private boolean isBinding;
    public List<Integer> taskIdsToDelete;

    public TasksAdapter(List<Task> data) {
        this.data = data;
        taskIdsToDelete = new ArrayList<>();
//        Log.d(TAG, "In TasksAdapter: " + String.valueOf(data.get(0)));
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(context == null) context = parent.getContext();
        View v = LayoutInflater.from(context).inflate(R.layout.partial_list_view, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        isBinding = true;
        Log.d(TAG, "In onBindViewHolder: " + position);
        Task task = data.get(position);
        holder.taskItem.setText(task.getTask());
        holder.taskStatus.setChecked(task.isChecked());
        if(holder.taskItem.getText().toString().equals("")){
            holder.taskItem.requestFocus();

            InputMethodManager imm = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);
            imm.showSoftInput(holder.taskItem, InputMethodManager.SHOW_IMPLICIT);
        }
        if(task.getId() == -1){
            addNewItemView = holder.addNewView;
            addNewItemView.setVisibility(View.VISIBLE);
            holder.itemsView.setVisibility(View.GONE);
        } else {
            holder.addNewView.setVisibility(View.GONE);
            holder.itemsView.setVisibility(View.VISIBLE);
            holder.taskItem.addTextChangedListener(holder);
        }
        isBinding = false;
    }

    @Override
    public int getItemCount() {
        return (data != null) ? data.size() : 0;
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements CompoundButton.OnCheckedChangeListener, View.OnClickListener, TextWatcher {
        public EditText taskItem;
        public TextView addNewItem;
        public AppCompatCheckBox taskStatus;
        public ImageButton taskRemove;
        public LinearLayout itemsView, addNewView;

        public ViewHolder(View itemView) {
            super(itemView);
            taskItem = (EditText) itemView.findViewById(R.id.partilal_list_item);
            taskStatus = (AppCompatCheckBox) itemView.findViewById(R.id.partilal_list_checkbox);
            taskRemove = (ImageButton) itemView.findViewById(R.id.partilal_list_remove);
            Drawable drawable = taskRemove.getDrawable();
            if (drawable != null) {
                drawable.mutate();
                drawable.setColorFilter(ContextCompat.getColor(context, R.color.primary_dark), PorterDuff.Mode.SRC_ATOP);
            }
            addNewView = (LinearLayout) itemView.findViewById(R.id.partilal_list_add_new);
            itemsView = (LinearLayout) itemView.findViewById(R.id.partilal_list_item_view);
            addNewItem = ((TextView) itemView.findViewById(R.id.partilal_list_add_new_text));
            taskStatus.setOnCheckedChangeListener(this);
            taskRemove.setOnClickListener(this);
            addNewItem.setOnClickListener(this);
        }

        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
            if(!isBinding){
                Task task = data.get(getAdapterPosition());
                task.setChecked(b);
                notifyDataSetChanged();
            }
        }

        @Override
        public void onClick(View view) {
            if(!isBinding) {
                switch (view.getId()) {
                    case R.id.partilal_list_add_new_text:
                        data.add(getAdapterPosition(), new Task("", false));
                        notifyDataSetChanged();
                        break;
                    case R.id.partilal_list_remove:
                        taskIdsToDelete.add(data.get(getAdapterPosition()).getId());
                        data.remove(getAdapterPosition());
                        notifyDataSetChanged();
                        break;
                    default:
                        break;
                }
            }
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            Log.d(TAG, "In beforeTextChanged");
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            data.get(getAdapterPosition()).setTask(charSequence.toString());
            if(charSequence.length() == 0 && getAdapterPosition() != 0){
                Log.d(TAG, "In onTextChanged if " + addNewItemView);
                if(addNewItemView != null) addNewItemView.setVisibility(View.GONE);
                if(addNewItemView != null) Log.d(TAG, "In onTextChanged if " + addNewItemView.getVisibility());
            } else {
                Log.d(TAG, "In onTextChanged else");
                if(addNewItemView != null) addNewItemView.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {
            Log.d(TAG, "In afterTextChanged");
        }
    }

}
