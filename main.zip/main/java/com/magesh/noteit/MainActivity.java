package com.magesh.noteit;

import android.app.SearchManager;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.magesh.noteit.fragments.AllFragment;
import com.magesh.noteit.fragments.FavoritesFragment;
import com.magesh.noteit.fragments.NotesFragment;
import com.magesh.noteit.fragments.RemindersFragment;
import com.magesh.noteit.fragments.TasksFragment;
import com.magesh.noteit.fragments.TrashFragment;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, SearchView.OnQueryTextListener{
    public final String TAG = "MainActivity";
    private Toolbar toolbar;
    private Fragment activeFragment;
    private DrawerLayout drawerLayout;
    private CoordinatorLayout coordinatorLayout;
    private ActionBarDrawerToggle drawerToggle;
    private FloatingActionButton fab, fab_notes,fab_tasks, fab_reminders;
    private Animation fab_open, fab_close, rotate_forward, rotate_backward;
    private Boolean isFabOpen = false;
    private String searchQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setUpToolBar();
        setUpNavigationDrawer();
        setUpFab();
        activeFragment = new NotesFragment();
        showFragment();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main, menu);
        // Associate searchable configuration with the SearchView
//        SearchManager searchManager = (SearchManager) getSystemService(SEARCH_SERVICE);
//        SearchView searchView = (SearchView) menu.findItem(R.id.menu_search).getActionView();
//        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
//        searchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_search:
                Intent intent = new Intent(this, SearchResultsActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }else {
            super.onBackPressed();
        }
        if(isFabOpen){
            animateFAB();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data != null && requestCode == 1){
            if(data.hasExtra("SAVED")){
                Snackbar.make(coordinatorLayout, "Note saved", Snackbar.LENGTH_LONG).show();
            }
        }
        showFragment();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.activity_main_fab:
                animateFAB();
                break;
            case R.id.activity_main_fab_notes:
                newNote();
                break;
            case R.id.activity_main_fab_tasks:
                newTask();
                break;
            case R.id.activity_main_fab_reminders:
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(isFabOpen){
            animateFAB();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(isFabOpen){
            animateFAB();
        }
    }

    private void setUpFab() {
        fab = (FloatingActionButton) findViewById(R.id.activity_main_fab);
        fab_notes = (FloatingActionButton) findViewById(R.id.activity_main_fab_notes);
        fab_tasks = (FloatingActionButton) findViewById(R.id.activity_main_fab_tasks);
        fab_reminders = (FloatingActionButton) findViewById(R.id.activity_main_fab_reminders);
        fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open);
        fab_close = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fab_close);
        rotate_forward = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate_forward);
        rotate_backward = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate_backward);
        fab.setOnClickListener(this);
        fab_notes.setOnClickListener(this);
        fab_tasks.setOnClickListener(this);
        fab_reminders.setOnClickListener(this);
    }

    public void setUpToolBar(){
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_menu_white_24dp);
        }
        setTitle(R.string.nav_notes);
    }

    public void setUpNavigationDrawer(){
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinator);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_drawer, R.string.close_drawer){
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }
        };
        drawerLayout.addDrawerListener(drawerToggle);

        NavigationView navigationView = (NavigationView) findViewById(R.id.drawer);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.isChecked()) {
                    item.setChecked(false);
                } else {
                    item.setChecked(true);
                }

                drawerLayout.closeDrawers();

                int menuId = item.getItemId();
                switch (menuId){
                    case R.id.nav_notes:
                        activeFragment = new NotesFragment();
                        fab.show();
                        if(isFabOpen) animateFAB();
                        setTitle(R.string.nav_notes);
                        showFragment();
                        return true;
                    case R.id.nav_check_list:
                        activeFragment = new TasksFragment();
                        fab.show();
                        if(isFabOpen) animateFAB();
                        setTitle(R.string.nav_check_list);
                        showFragment();
                        return true;
                    case R.id.nav_reminders:
                        activeFragment = new RemindersFragment();
                        fab.show();
                        if(isFabOpen) animateFAB();
                        setTitle(R.string.nav_reminders);
                        showFragment();
                        return true;
                    case R.id.nav_favorites:
                        activeFragment = new FavoritesFragment();
                        fab.hide();
                        if(isFabOpen) animateFAB();
                        setTitle(R.string.nav_favorites);
                        showFragment();
                        return true;
                    case R.id.nav_deleted:
                        activeFragment = new TrashFragment();
                        fab.hide();
                        if(isFabOpen) animateFAB();
                        setTitle(R.string.nav_deleted);
                        showFragment();
                        return true;
                    case R.id.nav_about:
                        Intent aboutIntent = new Intent(getApplicationContext(), AboutActivity.class);
                        startActivity(aboutIntent);
                        return true;
                    case R.id.nav_settings:
                        Intent settingsIntent = new Intent(getApplicationContext(), SettingsActivity.class);
                        startActivity(settingsIntent);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void showFragment() {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_frame, activeFragment);
        fragmentTransaction.commit();
    }

    public void animateFAB(){

        if(isFabOpen){

            fab.startAnimation(rotate_backward);
            fab_notes.startAnimation(fab_close);
            fab_tasks.startAnimation(fab_close);
            fab_reminders.startAnimation(fab_close);
            fab_notes.setClickable(false);
            fab_tasks.setClickable(false);
            fab_reminders.setClickable(false);
            isFabOpen = false;
        } else {
            fab.startAnimation(rotate_forward);
            fab_notes.startAnimation(fab_open);
            fab_tasks.startAnimation(fab_open);
            fab_reminders.startAnimation(fab_open);
            fab_notes.setClickable(true);
            fab_tasks.setClickable(true);
            fab_reminders.setClickable(true);
            isFabOpen = true;
        }
    }

    public void newNote(){
        Intent intent = new Intent(this, NotesActivity.class);
        startActivityForResult(intent, 1);
    }

    public void newTask(){
        Intent intent = new Intent(this, TasksActivity.class);
        startActivityForResult(intent, 1);
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        Log.d(TAG, "Searched: " + query);
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        Log.d(TAG, "Search: " + newText);
        Bundle bundle = new Bundle();
        bundle.putString("SEARCH_QUERY", newText);
        activeFragment = new AllFragment();
        activeFragment.setArguments(bundle);
        showFragment();
        return false;
    }
}
