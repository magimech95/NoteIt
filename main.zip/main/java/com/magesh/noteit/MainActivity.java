package com.magesh.noteit;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.magesh.noteit.fragments.FavoritesFragment;
import com.magesh.noteit.fragments.NotesFragment;
import com.magesh.noteit.fragments.RemindersFragment;
import com.magesh.noteit.fragments.TasksFragment;
import com.magesh.noteit.fragments.TrashFragment;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private Fragment activeFragment;
    private DrawerLayout drawerLayout;
    private CoordinatorLayout coordinatorLayout;
    private ActionBarDrawerToggle drawerToggle;
    private FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setUpToolBar();
        setUpNavigationDrawer();
        setUpFab();
        activeFragment = new NotesFragment();
        showFragment();
    }

    private void setUpFab() {
        fab = (FloatingActionButton) findViewById(R.id.create_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                newNote();
            }
        });
    }

    public void setUpToolBar(){
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_menu_white_24dp);
        }
        setTitle(R.string.nav_notes);
    }

    public void setUpNavigationDrawer(){
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinator);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_drawer, R.string.close_drawer){
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }
        };
        drawerLayout.addDrawerListener(drawerToggle);

        NavigationView navigationView = (NavigationView) findViewById(R.id.drawer);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.isChecked()) {
                    item.setChecked(false);
                } else {
                    item.setChecked(true);
                }

                drawerLayout.closeDrawers();

                int menuId = item.getItemId();
                switch (menuId){
                    case R.id.nav_notes:
                        activeFragment = new NotesFragment();
                        fab.show();
                        setTitle(R.string.nav_notes);
                        showFragment();
                        return true;
                    case R.id.nav_check_list:
                        activeFragment = new TasksFragment();
                        fab.show();
                        setTitle(R.string.nav_check_list);
                        showFragment();
                        return true;
                    case R.id.nav_reminders:
                        activeFragment = new RemindersFragment();
                        fab.show();
                        setTitle(R.string.nav_reminders);
                        showFragment();
                        return true;
                    case R.id.nav_favorites:
                        activeFragment = new FavoritesFragment();
                        fab.hide();
                        setTitle(R.string.nav_favorites);
                        showFragment();
                        return true;
                    case R.id.nav_deleted:
                        activeFragment = new TrashFragment();
                        fab.hide();
                        setTitle(R.string.nav_deleted);
                        showFragment();
                        return true;
                    case R.id.nav_about:
                        Intent aboutIntent = new Intent(getApplicationContext(), AboutActivity.class);
                        startActivity(aboutIntent);
                        return true;
                    case R.id.nav_settings:
                        Intent settingsIntent = new Intent(getApplicationContext(), SettingsActivity.class);
                        startActivity(settingsIntent);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void showFragment() {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_frame, activeFragment);
        fragmentTransaction.commit();
    }

    public void newNote(){
        Intent intent = new Intent(this, NotesActivity.class);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data != null && requestCode == 1){
            if(data.hasExtra("SAVED")){
                Snackbar.make(coordinatorLayout, "Note saved", Snackbar.LENGTH_LONG).show();
            }
        }
        showFragment();
    }
}
