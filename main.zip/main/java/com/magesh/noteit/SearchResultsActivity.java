package com.magesh.noteit;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import com.magesh.noteit.fragments.AllFragment;

public class SearchResultsActivity extends AppCompatActivity implements TextWatcher {
    public final String TAG = "SearchResultsActivity";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        setUpToolBar();
        EditText searchQuery = (EditText) findViewById(R.id.activity_search_title);
        searchQuery.addTextChangedListener(this);
    }

    private void setUpToolBar(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.activity_search_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        Bundle bundle = new Bundle();
        bundle.putString("SEARCH_QUERY", charSequence.toString());
        Fragment activeFragment = new AllFragment();
        activeFragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.activity_search_frame, activeFragment);
        fragmentTransaction.commit();
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }
}
