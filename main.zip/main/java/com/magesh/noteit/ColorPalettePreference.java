package com.magesh.noteit;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.preference.Preference;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ColorPalettePreference extends Preference {

    public ColorPalettePreference(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    @Override
    protected Object onGetDefaultValue(TypedArray a, int index) {
        return super.onGetDefaultValue(a, index);
    }

    public ColorPalettePreference(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setWidgetLayoutResource(android.R.layout.simple_list_item_1);
    }

    @Override
    protected void onBindView(View view) {
        super.onBindView(view);
//        ImageView imageView = (ImageView) view.findViewById(R.id.color_image_view);
//        Drawable background = imageView.getBackground();
//        if (background instanceof ShapeDrawable) {
//            ((ShapeDrawable)background).getPaint().setColor(Color.MAGENTA);
//        } else if (background instanceof GradientDrawable) {
//            ((GradientDrawable)background).setColor(Color.MAGENTA);
//        } else if (background instanceof ColorDrawable) {
//            ((ColorDrawable)background).setColor(Color.MAGENTA);
//        }
        TextView textView = (TextView) view.findViewById(android.R.id.text1);
        textView.setTextSize(10);
        textView.setTextColor(ContextCompat.getColor(getContext(), R.color.accent));
    }

    @Override
    protected void onSetInitialValue(boolean restorePersistedValue, Object defaultValue) {
        super.onSetInitialValue(restorePersistedValue, defaultValue);
    }
}
