package com.magesh.noteit;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.preference.DialogPreference;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;

import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;

import static com.magesh.noteit.SettingsActivity.INIT_COLOR_VALUE;

public class ColorPalettePreference extends DialogPreference implements RecyclerClickListener.OnClickListener {
    private static final String TAG = "PalettePreference : ";
    public static final String DEFAULT_COLOR = "#FFFFFF";
    private String[] colorsArray;
    private String[] colorsArrayNames;
    private ImageView imageView;

    public ColorPalettePreference(Context context, AttributeSet attrs) {
        super(context, attrs);
        setPersistent(false);
        setDialogLayoutResource(R.layout.color_palette);
        colorsArray = getContext().getResources().getStringArray(R.array.color_palette);
        colorsArrayNames = getContext().getResources().getStringArray(R.array.color_palette_titles);
    }

    @Override
    protected void onBindDialogView(View view) {
        super.onBindDialogView(view);
        TextView textView = (TextView) view.findViewById(R.id.color_palette_title);
        textView.setVisibility(View.GONE);
        ColorDialogAdapter colorDialogAdapter = new ColorDialogAdapter(colorsArray);
        RecyclerView colorView = (RecyclerView) view.findViewById(R.id.color_view);
        StaggeredGridLayoutManager colorLayoutManager = new StaggeredGridLayoutManager(5,1);
        colorLayoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        colorView.setLayoutManager(colorLayoutManager);
        colorView.setAdapter(colorDialogAdapter);
        RecyclerClickListener listener = new RecyclerClickListener(getContext(), colorView, this);
        colorView.addOnItemTouchListener(listener);
    }

    @Override
    protected void onBindView(View view) {
        super.onBindView(view);
        Log.d(TAG, "In onBindView");
        imageView = (ImageView) view.findViewById(R.id.preference_image_view);
        SharedPreferences sharedPreferences = getSharedPreferences();
        String color = sharedPreferences.getString(getKey(), INIT_COLOR_VALUE);
//        int position = Arrays.asList(colorsArray).indexOf(color);
//        setSummary(colorsArrayNames[position]);
//        Log.d(TAG, "In onBindView : " + colorsArrayNames[position]);
        changeViewColor(Color.parseColor(color));
    }

    private void changeViewColor(int color){
        Log.d(TAG, "In changeViewColor : " + color);
        Drawable background = imageView.getBackground();
        ((GradientDrawable) background).setColor(color);
    }

    @Override
    public void onItemClick(View view, int position) {
        Log.d(TAG, "In onItemClick : " + colorsArray[position]);
        SharedPreferences.Editor editor = getEditor();
        editor.putString(getKey(), colorsArray[position]);
        editor.commit();
        setSummary(colorsArrayNames[position]);
        getDialog().dismiss();
    }

    @Override
    public void onItemLongClick(View view, int position) {}
}
