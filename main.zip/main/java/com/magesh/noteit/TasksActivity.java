package com.magesh.noteit;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.Spanned;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.magesh.noteit.database.NotesContentProvider;
import com.magesh.noteit.database.NotesTable;
import com.magesh.noteit.database.TasksContentProvider;
import com.magesh.noteit.database.TasksTable;
import com.magesh.noteit.models.Note;
import com.magesh.noteit.models.Task;

import java.util.ArrayList;
import java.util.List;

import static com.magesh.noteit.SettingsActivity.INIT_COLOR_VALUE;

public class TasksActivity extends AppCompatActivity implements View.OnClickListener, ColorPaletteDialog.OnColorPickListener, RecyclerClickListener.OnClickListener{
    public final String TAG = "TasksActivity";
    private CoordinatorLayout coordinatorLayout;
    private LinearLayout container;
    private EditText noteTitle;
    private String noteColor;
    private Note note;
    private String[] paletteColors;
    private List<Task> data;
    private TasksAdapter recyclerAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tasks);
        setUpToolBar();
        setUpFab();
        initActivity();
    }

    private void setUpToolBar(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.activity_tasks_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.abc_ic_ab_back_material);
        changeMenuIconColor(upArrow);
        getSupportActionBar().setHomeAsUpIndicator(upArrow);
    }

    private void setUpFab() {
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.activity_tasks_fab);
        fab.setOnClickListener(this);
    }

    private void initActivity(){
        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.activity_tasks_coordinator);
        container = (LinearLayout) findViewById(R.id.activity_tasks_container);
        noteTitle = (EditText) findViewById(R.id.activity_tasks_title);
        noteColor = PreferenceManager.getDefaultSharedPreferences(this).getString(SettingsActivity.GeneralPreferencesFragment.PREF_DEFAULT_COLOR, INIT_COLOR_VALUE);
        paletteColors = getResources().getStringArray(R.array.color_palette);
        Intent intent = this.getIntent();
        data = new ArrayList<>();
        data.add(new Task("", false));
        if(intent.hasExtra("NOTE")){
            note = (Note) intent.getExtras().getSerializable("NOTE");
            if(note!=null){
                noteColor = (note.getColor() != null) ? note.getColor() : noteColor;
                noteTitle.setText(note.getTitle());
                Cursor cursor = getContentResolver().query(
                        TasksContentProvider.CONTENT_URI,
                        TasksTable.PROJECTIONS_ALL,
                        TasksTable.TASKS_UID + " = ?",
                        new String[]{String.valueOf(note.getId())},
                        TasksTable.SORT_ORDER_DEFAULT
                );
                Log.d(TAG, "In initActivity - data size-b: " + data.size());
                data.clear();
                if(cursor != null && cursor.getCount() > 0){
                    while (cursor.moveToNext()){
                        data.add(cursorToTask(cursor));
                    }
                }
                Log.d(TAG, "In initActivity - data size-a: " + data.size());
            }
        }
        data.add(new Task(-1));
        container.setBackgroundColor(Color.parseColor(noteColor));
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.activity_tasks_recycler);
        recyclerAdapter = new TasksAdapter(data);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(recyclerAdapter);
        RecyclerClickListener listener = new RecyclerClickListener(this, recyclerView, this);
        recyclerView.addOnItemTouchListener(listener);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        setResult(2);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_notes, menu);
        changeMenuIconColor(menu.findItem(R.id.menu_note_palette).getIcon());
        changeMenuIconColor(menu.findItem(R.id.menu_note_share).getIcon());
        changeMenuIconColor(menu.findItem(R.id.menu_note_delete).getIcon());
        return true;
    }

    public void changeMenuIconColor(Drawable drawable){
        if (drawable != null) {
            drawable.mutate();
            drawable.setColorFilter(ContextCompat.getColor(this, R.color.primary_dark), PorterDuff.Mode.SRC_ATOP);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_note_palette:
                ColorPaletteDialog colorPaletteDialog = new ColorPaletteDialog();
                colorPaletteDialog.setListener(this);
                colorPaletteDialog.show(getSupportFragmentManager(), "COLOR_PALETTE");
                return true;
            case R.id.menu_note_delete:
                if(note != null){
                    getContentResolver().delete(
                            NotesContentProvider.CONTENT_URI,
                            NotesTable.NOTES_ID + " = ?",
                            new String[] {String.valueOf(note.getId())}
                    );
                }
                Intent intent = new Intent();
                intent.putExtra("DELETED", true);
                setResult(1, intent);
                finish();
                return true;
            case R.id.menu_note_share:
                String noteText = "";
                Cursor cursor = getContentResolver().query(
                        TasksContentProvider.CONTENT_URI,
                        TasksTable.PROJECTIONS_ALL,
                        TasksTable.TASKS_UID + " = ?",
                        new String[]{String.valueOf(note.getId())},
                        TasksTable.SORT_ORDER_DEFAULT
                );
                if(cursor != null && cursor.getCount() > 0){
                    while (cursor.moveToNext()){
                        if(cursor.getInt(cursor.getColumnIndex(TasksTable.TASKS_STATUS)) != 0){
                            noteText += "&#9745; " + cursor.getString(cursor.getColumnIndex(TasksTable.TASKS_LIST)) + "<br/>";
                        } else {
                            noteText += "&#9744; " + cursor.getString(cursor.getColumnIndex(TasksTable.TASKS_LIST)) + "<br/>";
                        }
                    }
                    cursor.close();
                }
                Spanned htmlString = Html.fromHtml(noteText);
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, noteTitle.getText().toString());
                sharingIntent.putExtra(Intent.EXTRA_TEXT, htmlString.toString());
                startActivity(Intent.createChooser(sharingIntent, "Share using"));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onColorPick(int position) {
        noteColor = paletteColors[position];
        container.setBackgroundColor(Color.parseColor(noteColor));
    }

    @Override
    public void onClick(View view) {
        if(TextUtils.isEmpty(noteTitle.getText())){
            Snackbar.make(coordinatorLayout, R.string.new_note_title_error, Snackbar.LENGTH_LONG).show();
            return;
        }
        ContentValues values = new ContentValues();
        values.put(NotesTable.NOTES_TITLE, noteTitle.getText().toString());
        values.put(NotesTable.NOTES_NOTE, getPackageName());
        values.put(NotesTable.NOTES_STATUS, 1);
        values.put(NotesTable.NOTES_COLOR, noteColor);
        values.put(NotesTable.NOTES_LAST_MODIFIED_AT, System.currentTimeMillis());
        if(note == null){
            values.put(NotesTable.NOTES_CREATED_AT, System.currentTimeMillis());
            Uri uri = getContentResolver().insert(NotesContentProvider.CONTENT_URI, values);
            for(Task task : data){
                if(task.getTask() != null && !task.getTask().isEmpty()){
                    ContentValues taskValues = new ContentValues();
                    taskValues.put(TasksTable.TASKS_UID, ContentUris.parseId(uri));
                    taskValues.put(TasksTable.TASKS_LIST, task.getTask());
                    taskValues.put(TasksTable.TASKS_STATUS, task.isChecked());
                    getContentResolver().insert(TasksContentProvider.CONTENT_URI, taskValues);
                }
            }
        } else {
            getContentResolver().update(
                    NotesContentProvider.CONTENT_URI,
                    values,
                    NotesTable.NOTES_ID + " = ?",
                    new String[] {String.valueOf(note.getId())}
            );
            for(Task task : data){
                ContentValues taskValues = new ContentValues();
                taskValues.put(TasksTable.TASKS_UID, note.getId());
                taskValues.put(TasksTable.TASKS_LIST, task.getTask());
                taskValues.put(TasksTable.TASKS_STATUS, task.isChecked());
                if(task.getId() == 0 && task.getTask() != null && !task.getTask().isEmpty()){
                    Log.d(TAG, "In save update: " + task.getTask());
                    getContentResolver().insert(TasksContentProvider.CONTENT_URI, taskValues);
                } else {
                    if(task.getTask() != null && !task.getTask().isEmpty()){
                        getContentResolver().update(
                                TasksContentProvider.CONTENT_URI,
                                taskValues,
                                TasksTable.TASKS_ID + " = ?",
                                new String[] {String.valueOf(task.getId())}
                        );
                    } else {
                        recyclerAdapter.taskIdsToDelete.add(task.getId());
                    }
                }
            }
            for(int i : recyclerAdapter.taskIdsToDelete){
                getContentResolver().delete(
                        TasksContentProvider.CONTENT_URI,
                        TasksTable.TASKS_ID + " = ?",
                        new String[] {String.valueOf(i)}
                );
            }
        }
        Intent intent = new Intent();
        intent.putExtra("SAVED", true);
        setResult(1, intent);
        finish();
    }

    public Task cursorToTask(Cursor cursor){
        return new Task(
                cursor.getInt(cursor.getColumnIndex(TasksTable.TASKS_UID)),
                cursor.getString(cursor.getColumnIndex(TasksTable.TASKS_LIST)),
                (cursor.getInt(cursor.getColumnIndex(TasksTable.TASKS_STATUS)) != 0),
                cursor.getInt(cursor.getColumnIndex(TasksTable.TASKS_ID))
        );
    }

    @Override
    public void onItemClick(View view, int position) {

    }

    @Override
    public void onItemLongClick(View view, int position) {

    }
}
