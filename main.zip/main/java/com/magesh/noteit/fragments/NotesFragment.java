package com.magesh.noteit.fragments;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.magesh.noteit.CreateNoteActivity;
import com.magesh.noteit.NotesActivity;
import com.magesh.noteit.R;
import com.magesh.noteit.RecyclerAdapter;
import com.magesh.noteit.RecyclerClickListener;
import com.magesh.noteit.database.NotesContentProvider;
import com.magesh.noteit.database.NotesTable;
import com.magesh.noteit.db.DbHandler;
import com.magesh.noteit.models.Note;

import java.util.ArrayList;
import java.util.List;

public class NotesFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>, RecyclerClickListener.OnClickListener{
    private static final String TAG = "DEBUG";
    private RecyclerView recyclerView;
    private RecyclerAdapter recyclerAdapter;
    private List<Note> notesList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "In onCreateView");
        recyclerView = (RecyclerView) inflater.inflate(R.layout.fragment_recycler_view, container, false);;
        recyclerAdapter = new RecyclerAdapter(getContext(), notesList);
        recyclerView.setHasFixedSize(true);
        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, 1);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(recyclerAdapter);
        RecyclerClickListener listener = new RecyclerClickListener(getContext(), recyclerView, this);
        recyclerView.addOnItemTouchListener(listener);
        getLoaderManager().initLoader(0, null, this);
        return recyclerView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            if(data.hasExtra("SAVED")){
                Snackbar.make(recyclerView, "Note saved", Snackbar.LENGTH_LONG).show();
            } else if(data.hasExtra("DELETED")){
                Snackbar.make(recyclerView, "Note deleted", Snackbar.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Log.d(TAG, "In onCreateLoader");
        return new CursorLoader(getActivity(), NotesContentProvider.CONTENT_URI, null, NotesTable.NOTES_STATUS + " = 1", null, NotesTable.SORT_ORDER_DEFAULT);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        Log.d(TAG, "In onLoadFinished");
        if(data != null && data.getCount() > 0){
            if(notesList != null) notesList.clear();
            while (data.moveToNext()){
                notesList.add(cursorToNote(data));
                Log.d(TAG, "NOTE TITLE: " + cursorToNote(data));
            }
            Log.d(TAG, "CURSOR SIZE: " + data.getCount());
        } else {
            //TODO show empty view
            Log.d(TAG, "CURSOR IS EMPTY");
        }
        recyclerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        Log.d(TAG, "In onLoaderReset");
    }

    @Override
    public void onItemClick(View view, int position) {
        Log.d(TAG, "In onItemClick");
        Intent intent = new Intent(getContext(), NotesActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("NOTE", notesList.get(position));
        intent.putExtras(bundle);
        startActivityForResult(intent, 1);
    }

    @Override
    public void onItemLongClick(View view, int position) {
        Log.d(TAG, "In onItemLongClick");
    }

    public Note cursorToNote(Cursor cursor){
        Log.d(TAG, "In cursorToNote");
        return new Note(
                cursor.getInt(cursor.getColumnIndex(NotesTable.NOTES_ID)),
                cursor.getString(cursor.getColumnIndex(NotesTable.NOTES_TITLE)),
                cursor.getString(cursor.getColumnIndex(NotesTable.NOTES_NOTE)),
                cursor.getInt(cursor.getColumnIndex(NotesTable.NOTES_STATUS)),
                cursor.getString(cursor.getColumnIndex(NotesTable.NOTES_COLOR)),
                cursor.getLong(cursor.getColumnIndex(NotesTable.NOTES_CREATED_AT)),
                cursor.getLong(cursor.getColumnIndex(NotesTable.NOTES_LAST_MODIFIED_AT))
            );
    }
}
