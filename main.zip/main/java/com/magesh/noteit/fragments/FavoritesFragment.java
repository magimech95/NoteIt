package com.magesh.noteit.fragments;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.ActionMode;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.magesh.noteit.ColorPaletteDialog;
import com.magesh.noteit.DataAdapter;
import com.magesh.noteit.NotesActivity;
import com.magesh.noteit.R;
import com.magesh.noteit.RecyclerClickListener;
import com.magesh.noteit.database.NotesContentProvider;
import com.magesh.noteit.database.NotesTable;
import com.magesh.noteit.models.Note;

import java.util.ArrayList;
import java.util.List;

public class FavoritesFragment extends Fragment implements
        LoaderManager.LoaderCallbacks<Cursor>,
        RecyclerClickListener.OnClickListener,
        ActionMode.Callback,
        ColorPaletteDialog.OnColorPickListener {
    private static final String TAG = "FavoritesFragment : ";
    private RecyclerView recyclerView;
    private TextView emptyTextView;
    private DataAdapter recyclerAdapter;
    private List<Note> notesList = new ArrayList<>();
    private ActionMode actionMode;

    public FavoritesFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "In onCreateView");
        View fragmentView = inflater.inflate(R.layout.fragment_common, container, false);;
        recyclerView = (RecyclerView) fragmentView.findViewById(R.id.fragment_common_recycler_view);
        emptyTextView = (TextView) fragmentView.findViewById(R.id.fragment_common_empty_view);
        recyclerAdapter = new DataAdapter(notesList);
        recyclerView.setHasFixedSize(true);
        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, 1);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(recyclerAdapter);
        RecyclerClickListener listener = new RecyclerClickListener(getContext(), recyclerView, this);
        recyclerView.addOnItemTouchListener(listener);
        getLoaderManager().initLoader(0, null, this);
        return fragmentView;
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Log.d(TAG, "In onCreateLoader");
        return new CursorLoader(
                getActivity(),
                NotesContentProvider.CONTENT_URI,
                null,
                NotesTable.NOTES_STATUS + " = ?",
                new String[] {String.valueOf(3)},
                NotesTable.SORT_ORDER_DEFAULT
        );
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        Log.d(TAG, "In onLoadFinished");
        if(notesList != null) notesList.clear();
        if(data != null && data.getCount() > 0){
            while (data.moveToNext()){
                notesList.add(cursorToNote(data));
            }
            showEmptyView(false);
        } else {
            showEmptyView(true);
        }
        recyclerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        Log.d(TAG, "In onLoaderReset");
    }

    public void showEmptyView(boolean visible){
        if(visible){
            Log.d(TAG, "In showEmptyView(true)");
            emptyTextView.setText("Your favorite items will appear here");
            recyclerView.setVisibility(View.GONE);
            emptyTextView.setVisibility(View.VISIBLE);
        } else {
            Log.d(TAG, "In showEmptyView(false)");
            emptyTextView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onItemClick(View view, int position) {
        if(actionMode == null){
            Log.d(TAG, "In onItemClick");
            Intent intent = new Intent(getContext(), NotesActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("NOTE", notesList.get(position));
            intent.putExtras(bundle);
            startActivityForResult(intent, 1);
        } else {
            onItemLongClick(view, position);
        }
    }

    @Override
    public void onItemLongClick(View view, int position) {
        Log.d(TAG, "In onItemLongClick");
        recyclerAdapter.toggleSelection(position);
        Log.d(TAG, String.valueOf(recyclerAdapter.getSelectedIds()));
        boolean hasCheckedItems = recyclerAdapter.getSelectedCount()>0;
        if(hasCheckedItems && actionMode==null){
            actionMode = ((AppCompatActivity) getActivity()).startSupportActionMode(this);
        }else if(!hasCheckedItems && actionMode!=null){
            actionMode.finish();
        }
        if(actionMode!=null){
            actionMode.setTitle(String.valueOf(recyclerAdapter.getSelectedCount()));
        }
    }

    public Note cursorToNote(Cursor cursor){
        Log.d(TAG, "In cursorToNote");
        return new Note(
                cursor.getInt(cursor.getColumnIndex(NotesTable.NOTES_ID)),
                cursor.getString(cursor.getColumnIndex(NotesTable.NOTES_TITLE)),
                cursor.getString(cursor.getColumnIndex(NotesTable.NOTES_NOTE)),
                cursor.getInt(cursor.getColumnIndex(NotesTable.NOTES_STATUS)),
                cursor.getString(cursor.getColumnIndex(NotesTable.NOTES_COLOR)),
                cursor.getLong(cursor.getColumnIndex(NotesTable.NOTES_CREATED_AT)),
                cursor.getLong(cursor.getColumnIndex(NotesTable.NOTES_LAST_MODIFIED_AT))
            );
    }

    @Override
    public boolean onCreateActionMode(ActionMode mode, Menu menu) {
        mode.getMenuInflater().inflate(R.menu.action_mode_notes, menu);
        return true;
    }

    @Override
    public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
        return false;
    }

    @Override
    public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_mode_notes_delete:
                deleteSelectedItems();
                return true;
            case R.id.action_mode_notes_favorite:
                return true;
            case R.id.action_mode_notes_palette:
                ColorPaletteDialog colorPaletteDialog = new ColorPaletteDialog();
                colorPaletteDialog.setListener(this);
                colorPaletteDialog.show(getFragmentManager(), "COLOR_PALETTE");
                return true;
            default:
                return false;
        }
    }

    @Override
    public void onDestroyActionMode(ActionMode mode) {
        actionMode = null;
        recyclerAdapter.removeSelection();
    }

    @Override
    public void onColorPick(int position) {
        String[] colorsArray = getActivity().getResources().getStringArray(R.array.color_palette);
        SparseBooleanArray selectedIds = recyclerAdapter.getSelectedIds();
        for(int i = (selectedIds.size()-1); i >= 0; i--){
            if(selectedIds.valueAt(i)){
                ContentValues contentValues = new ContentValues();
                contentValues.put(NotesTable.NOTES_COLOR, colorsArray[position]);
                getContext().getContentResolver().update(
                        NotesContentProvider.CONTENT_URI,
                        contentValues,
                        NotesTable.NOTES_ID + " = ?",
                        new String[] {String.valueOf(notesList.get(selectedIds.keyAt(i)).getId())}
                );
            }
        }
        actionMode.finish();
    }

    private void deleteSelectedItems() {
        SparseBooleanArray selectedIds = recyclerAdapter.getSelectedIds();
        final List<Integer> arrayIds = new ArrayList<>();
        for(int i = (selectedIds.size()-1); i >= 0; i--){
            if(selectedIds.valueAt(i)){
                int id = notesList.get(selectedIds.keyAt(i)).getId();
                arrayIds.add(id);
                ContentValues contentValues = new ContentValues();
                contentValues.put(NotesTable.NOTES_STATUS, NotesTable.STATUS_DELETED_TRUE);
                getContext().getContentResolver().update(
                        NotesContentProvider.CONTENT_URI,
                        contentValues,
                        NotesTable.NOTES_ID + " = ?",
                        new String[] {String.valueOf(id)}
                );
            }
        }
        actionMode.finish();
        Snackbar.make(recyclerView, arrayIds.size() + " items deleted", Snackbar.LENGTH_LONG)
                .setAction("UNDO", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        for(int id : arrayIds){
                            ContentValues contentValues = new ContentValues();
                            contentValues.put(NotesTable.NOTES_STATUS, NotesTable.STATUS_DELETED_FALSE);
                            getContext().getContentResolver().update(
                                    NotesContentProvider.CONTENT_URI,
                                    contentValues,
                                    NotesTable.NOTES_ID + " = ?",
                                    new String[] {String.valueOf(id)}
                            );
                        }
                    }
                })
                .show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(actionMode != null){
            actionMode.finish();
        }
    }
}
