package com.magesh.noteit;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.magesh.noteit.database.NotesContentProvider;
import com.magesh.noteit.database.NotesTable;
import com.magesh.noteit.models.Note;

public class NotesActivity extends AppCompatActivity implements View.OnClickListener, ColorPaletteDialog.OnColorPickListener{
    private CoordinatorLayout coordinatorLayout;
    private EditText noteTitle;
    private EditText noteContent;
    private String noteColor;
    private Note note;
    private String[] paletteColors;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);
        setUpToolBar();
        setUpFab();
        initActivity();
    }

    private void setUpToolBar(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.activity_notes_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.abc_ic_ab_back_material);
        changeMenuIconColor(upArrow);
        getSupportActionBar().setHomeAsUpIndicator(upArrow);
    }

    private void setUpFab() {
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.activity_notes_fab);
        fab.setOnClickListener(this);
    }

    private void initActivity(){
        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.activity_notes_coordinator);
        noteTitle = (EditText) findViewById(R.id.activity_notes_title);
        noteContent = (EditText) findViewById(R.id.activity_notes_content);
        noteColor = PreferenceManager.getDefaultSharedPreferences(this).getString(SettingsActivity.GeneralPreferencesFragment.PREF_DEFAULT_COLOR, "");
        paletteColors = getResources().getStringArray(R.array.color_palette);
        Intent intent = this.getIntent();
        if(intent.hasExtra("NOTE")){
            note = (Note) intent.getExtras().getSerializable("NOTE");
            noteColor = (note.getColor() != null) ? note.getColor() : noteColor;
            noteTitle.setText(note.getTitle());
            noteContent.setText(note.getNote());
        } else {
            noteContent.requestFocus();
        }
        noteContent.setBackgroundColor(Color.parseColor(noteColor));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        setResult(2);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_notes, menu);
        changeMenuIconColor(menu.findItem(R.id.menu_note_palette).getIcon());
        changeMenuIconColor(menu.findItem(R.id.menu_note_share).getIcon());
        changeMenuIconColor(menu.findItem(R.id.menu_note_delete).getIcon());
        return true;
    }

    public void changeMenuIconColor(Drawable drawable){
        if (drawable != null) {
            drawable.mutate();
            drawable.setColorFilter(ContextCompat.getColor(this, R.color.primary_dark), PorterDuff.Mode.SRC_ATOP);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_note_palette:
                ColorPaletteDialog colorPaletteDialog = new ColorPaletteDialog();
                colorPaletteDialog.setListener(this);
                colorPaletteDialog.show(getSupportFragmentManager(), "COLOR_PALETTE");
                return true;
            case R.id.menu_note_delete:
                Intent intent = new Intent();
                intent.putExtra("DELETED", true);
                if(note != null){
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(NotesTable.NOTES_STATUS, NotesTable.STATUS_DELETED_TRUE);
                    getContentResolver().update(
                            NotesContentProvider.CONTENT_URI,
                            contentValues,
                            NotesTable.NOTES_ID + " = ?",
                            new String[] {String.valueOf(note.getId())}
                    );
                    intent.putExtra("ID", note.getId());
                }
                setResult(1, intent);
                finish();
                return true;
            case R.id.menu_note_share:
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, noteTitle.getText().toString());
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, noteContent.getText().toString());
                startActivity(Intent.createChooser(sharingIntent, "Share using"));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onColorPick(int position) {
        noteColor = paletteColors[position];
        noteContent.setBackgroundColor(Color.parseColor(noteColor));
    }

    @Override
    public void onClick(View view) {
        if(TextUtils.isEmpty(noteTitle.getText())){
            Snackbar.make(coordinatorLayout, R.string.new_note_title_error, Snackbar.LENGTH_LONG).show();
            return;
        }
        ContentValues values = new ContentValues();
        values.put(NotesTable.NOTES_TITLE, noteTitle.getText().toString());
        values.put(NotesTable.NOTES_NOTE, noteContent.getText().toString());
        values.put(NotesTable.NOTES_STATUS, 1);
        values.put(NotesTable.NOTES_COLOR, noteColor);
        values.put(NotesTable.NOTES_LAST_MODIFIED_AT, System.currentTimeMillis());
        if(note == null){
            values.put(NotesTable.NOTES_CREATED_AT, System.currentTimeMillis());
            getContentResolver().insert(NotesContentProvider.CONTENT_URI, values);
        } else {
            getContentResolver().update(
                    NotesContentProvider.CONTENT_URI,
                    values,
                    NotesTable.NOTES_ID + " = ?",
                    new String[] {String.valueOf(note.getId())}
            );
        }
        Intent intent = new Intent();
        intent.putExtra("SAVED", true);
        setResult(1, intent);
        finish();
    }
}
