package com.magesh.noteit;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.magesh.noteit.db.DbHandler;
import com.magesh.noteit.models.Note;

public class CreateNoteActivity extends AppCompatActivity {
    private CoordinatorLayout coordinatorLayout;
    private EditText note_title;
    private EditText note;
    //TODO load default color from shared prefs
    private String color = "#FFFFFF";
    private Note update_note;
    private DbHandler dbHandler;
    private int return_position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_note);

        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.new_note_coordinator);
        note_title = (EditText) findViewById(R.id.new_note_title);
        note = (EditText) findViewById(R.id.new_note_content);

        setUpToolBar();
        setUpFab();

        dbHandler = new DbHandler(this);

        Intent intent = this.getIntent();
        Bundle bundle = intent.getExtras();

        if(intent.hasExtra("NOTE")){
            Note update_note = (Note) bundle.getSerializable("NOTE");
            note_title.setText(update_note.getTitle());
            note.setText(update_note.getNote());
            color = update_note.getColor();
            note.setBackgroundColor(Color.parseColor(update_note.getColor()));
        }

//        if(intent.hasExtra("ID")){
//            Bundle extras = intent.getExtras();
//            update_note = dbHandler.getNote(extras.getInt("ID"));
//            return_position = extras.getInt("POSITION");
//        }

    }

    public void setUpToolBar(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.new_note_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void setUpFab() {
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.note_save_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveNote();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_notes, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_note_delete:
                if(update_note!=null){
                    dbHandler.deleteNote(update_note);
                    Intent intent = new Intent();
                    intent.putExtra("DELETED", true);
                    intent.putExtra("ID", update_note.get_id());
                    intent.putExtra("POSITION", return_position);
                    setResult(2, intent);
                    finish();
                }
                return true;
            case R.id.menu_note_palette:
                final String[] colorsArray = getResources().getStringArray(R.array.color_palette);
                ColorPaletteDialog colorPaletteDialog = new ColorPaletteDialog();
                colorPaletteDialog.setListener(new ColorPaletteDialog.OnColorPickListener() {
                    @Override
                    public void onColorPick(int position) {
                        color = colorsArray[position];
                        note.setBackgroundColor(Color.parseColor(colorsArray[position]));
                    }
                });
                colorPaletteDialog.show(getSupportFragmentManager(), "color");
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void saveNote(){
        String edit_title = note_title.getText().toString();
        String edit_note = note.getText().toString();

        if(TextUtils.isEmpty(edit_title)){
            Snackbar.make(coordinatorLayout, R.string.new_note_title_error, Snackbar.LENGTH_LONG).show();
            return;
        }

        Intent intent = new Intent();
        intent.putExtra("SAVED", true);

        if(update_note!=null){
            update_note.setTitle(edit_title);
            update_note.setNote(edit_note);
            update_note.setColor(color);
            update_note.setLast_modified_at(System.currentTimeMillis());
            dbHandler.updateNote(update_note);
            intent.putExtra("ID", update_note.get_id());
            intent.putExtra("POSITION", return_position);
            setResult(2, intent);
            finish();
        }
        else {
            Note new_note = new Note(0, edit_title, edit_note, 1, color, System.currentTimeMillis(), System.currentTimeMillis());
            dbHandler.addNote(new_note);
            setResult(1, intent);
            finish();
        }

    }
}
