package com.magesh.noteit;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.magesh.noteit.db.DbHandler;
import com.magesh.noteit.models.Note;

import java.util.ArrayList;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
    private Context context;
    private List<Note> notes;
    private SparseBooleanArray selectedIds;
    private DbHandler dbHandler;

    public RecyclerAdapter(Context context, List<Note> notes) {
        this.context = context;
        this.notes = new ArrayList<Note>(notes);
        selectedIds = new SparseBooleanArray();
        dbHandler = new DbHandler(context);
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView title;
        TextView note;

        public ViewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.note_title);
            note = (TextView) itemView.findViewById(R.id.note_content);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Note note = notes.get(position);
        holder.title.setText(note.getTitle());
        holder.note.setText(note.getNote());
        if(isSelected(position)) {
            ((CardView) holder.itemView).setCardBackgroundColor(ContextCompat.getColor(context, R.color.primary_light));
        } else {
             int color = (note.getColor()!=null) ? Color.parseColor(note.getColor()) : Color.WHITE;
            ((CardView) holder.itemView).setCardBackgroundColor(color);
        }
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public int getSelectedCount(){
        return selectedIds.size();
    }

    public boolean isSelected(int position){
        return selectedIds.get(position);
    }

    public void removeSelection(){
        selectedIds.clear();
        notifyDataSetChanged();
    }

    public SparseBooleanArray getAllSelections(){
        return selectedIds;
    }

    public void toggleSelection(int position){
        selectView(position, !selectedIds.get(position));
    }

    public void selectView(int position, boolean value){
        if(value) selectedIds.put(position, value);
        else selectedIds.delete(position);
        notifyDataSetChanged();
    }


    public void removeNotes(SparseBooleanArray allSelections){
//        List<Note> original_notes = new ArrayList<Note>(notes);
        for(int i = (allSelections.size()-1); i >= 0; i--){
            if(allSelections.valueAt(i)){
                notes.remove(allSelections.keyAt(i));
            }
        }
        notifyDataSetChanged();
    }

    public void deleteNotes(List<Note> original_notes, SparseBooleanArray allSelections, boolean delete){
        for(int i = (allSelections.size()-1); i >= 0; i--){
            if(allSelections.valueAt(i)){
                Note note = original_notes.get(allSelections.keyAt(i));
                if(dbHandler.getNote(note.get_id()).getStatus()==1) dbHandler.deleteNote(note);
                else dbHandler.deleteNotePermanent(note);
                if(delete) notes.remove(allSelections.keyAt(i));
            }
        }
        if(!delete) notes = new ArrayList<Note>(original_notes);
        notifyDataSetChanged();
    }

    public void restoreNotes(List<Note> original_notes, SparseBooleanArray allSelections, boolean delete){
        for(int i = (allSelections.size()-1); i >= 0; i--){
            if(allSelections.valueAt(i)){
                dbHandler.restoreNote(original_notes.get(allSelections.keyAt(i)));
                if(!delete) notes.remove(allSelections.keyAt(i));
            }
        }
        if(delete) notes = new ArrayList<Note>(original_notes);
        notifyDataSetChanged();
    }

    public void updateNotes(List<Note> original_notes){
        notes = original_notes;
        notifyDataSetChanged();
    }

}
