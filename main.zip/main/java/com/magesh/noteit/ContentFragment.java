package com.magesh.noteit;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.ActionMode;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.magesh.noteit.db.DbHandler;
import com.magesh.noteit.models.Note;

import java.util.ArrayList;
import java.util.List;

public class ContentFragment extends Fragment {
    private List<Note> notes;
    private Context context;
    private ActionMode actionMode;
    private RecyclerView recyclerView;
    private RecyclerAdapter adapter;
    private int menuId;
    private ViewGroup container;
    private DbHandler dbHandler;

    public ContentFragment() {
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 2){
            final int id = data.getIntExtra("ID", -1);
            final int return_position = data.getIntExtra("POSITION", -1);
            if(id != -1){
                final Note note = notes.get(return_position);
                notes.remove(return_position);
                adapter.updateNotes(notes);
                Snackbar.make(recyclerView, R.string.info_binned, Snackbar.LENGTH_LONG)
                        .setAction("RESTORE", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dbHandler.restoreNote(note);
                                notes.add(return_position, note);
                                adapter.updateNotes(notes);
                                Snackbar.make(recyclerView, R.string.info_restored, Snackbar.LENGTH_LONG).show();
                            }
                        }).show();
            }
            if(data.getBooleanExtra("SAVED", false)){
                notes.set(return_position, dbHandler.getNote(id));
                adapter.updateNotes(notes);
                Snackbar.make(recyclerView, "Note saved", Snackbar.LENGTH_LONG).show();
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        context = getActivity();
        dbHandler = new DbHandler(context);

        Bundle bundle = getArguments();
        menuId = bundle.getInt("MENU_ID");

        recyclerView = (RecyclerView) inflater.inflate(R.layout.notes_fragment, container, false);;
        this.container = container;

        switch (menuId){
            case R.id.nav_notes:
                notes = dbHandler.getAllNotes(1);
                if(notes.isEmpty()){
                    return generateEmptyView(R.string.empty_notes);
                }
                adapter = new RecyclerAdapter(context, notes);

                return generateRecyclerView(recyclerView, adapter, new RecyclerItemClickListener(context, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        if(actionMode==null) {
                            Intent intent = new Intent(context, CreateNoteActivity.class);
                            Note clicked_note = notes.get(position);
                            intent.putExtra("ID", clicked_note.get_id());
                            intent.putExtra("STATUS", 1);
                            intent.putExtra("POSITION", position);
                            startActivityForResult(intent, 2);
                        } else {
                            selectItem(position, view, R.menu.action_mode_notes);
                        }
                    }

                    @Override
                    public void onLongClick(View view, int position) {
                        selectItem(position, view, R.menu.action_mode_notes);
                    }
                }));
            case R.id.nav_check_list:
                return generateEmptyView(R.string.empty_lists);
            case R.id.nav_reminders:
                return generateEmptyView(R.string.empty_reminders);
            case R.id.nav_favorites:
                return generateEmptyView(R.string.empty_favorites);
            case R.id.nav_deleted:
                notes = dbHandler.getAllNotes(0);
                if(notes.isEmpty()){
                    return generateEmptyView(R.string.empty_deleted);
                }
                adapter = new RecyclerAdapter(context, notes);

                return generateRecyclerView(recyclerView, adapter, new RecyclerItemClickListener(context, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        if(actionMode==null) {
                            Intent intent = new Intent(context, CreateNoteActivity.class);
                            Note clicked_note = notes.get(position);
                            intent.putExtra("ID", clicked_note.get_id());
                            intent.putExtra("STATUS", 0);
                            startActivity(intent);
                        } else {
                            selectItem(position, view, R.menu.action_mode_trash);
                        }
                    }

                    @Override
                    public void onLongClick(View view, int position) {
                        selectItem(position, view, R.menu.action_mode_trash);
                    }
                }));
            default:
                return recyclerView;
        }
    }

    private void selectItem(int position, View view, int menuRes) {
        adapter.toggleSelection(position);

        boolean hasCheckedItems = adapter.getSelectedCount()>0;

        if(hasCheckedItems && actionMode==null){
            actionMode = ((AppCompatActivity) context).startSupportActionMode(new InitActionMode(menuRes));
        }else if(!hasCheckedItems && actionMode!=null){
            actionMode.finish();
        }

        if(actionMode!=null){
            actionMode.setTitle(String.valueOf(adapter.getSelectedCount()));
        }
    }

    private View generateRecyclerView(View view, RecyclerView.Adapter adapter, RecyclerView.OnItemTouchListener listener) {
        RecyclerView recyclerView = (RecyclerView) view;
        recyclerView.setHasFixedSize(true);

        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, 1);
        layoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(adapter);
        recyclerView.addOnItemTouchListener(listener);

        return recyclerView;
    }

    private View generateEmptyView(int empty_string) {
        TextView emptyTextView = new TextView(context);
        emptyTextView.setText(empty_string);
        emptyTextView.setGravity(Gravity.CENTER);
        emptyTextView.setTextSize(20);
        emptyTextView.setPadding(70,0,70,0);
        emptyTextView.setLineSpacing(10,1);
        return emptyTextView;
    }

    public void stopActionMode(){
        actionMode = null;
    }

    public void refreshFragment(){
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        Fragment fragment = this;
        this.onDestroy();
        transaction.remove(this);
        transaction.replace(container.getId(), fragment);
        transaction.commit();
    }

    public static class RecyclerItemClickListener implements RecyclerView.OnItemTouchListener {
        private OnItemClickListener mListener;

        public interface OnItemClickListener {
            void onItemClick(View view, int position);
            void onLongClick(View view, int position);
        }

        GestureDetector mGestureDetector;

        public RecyclerItemClickListener(Context context, final RecyclerView recyclerView, final OnItemClickListener listener) {
            mListener = listener;
            mGestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View childView = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if(childView!=null && mListener!= null){
                        mListener.onLongClick(childView, recyclerView.getChildAdapterPosition(childView));
                    }
                }

            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView view, MotionEvent e) {
            View childView = view.findChildViewUnder(e.getX(), e.getY());
            if (childView != null && mListener != null && mGestureDetector.onTouchEvent(e)) {
                mListener.onItemClick(childView, view.getChildAdapterPosition(childView));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView view, MotionEvent motionEvent) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

    public class InitActionMode implements ActionMode.Callback{
        private int menuRes;
        public InitActionMode(int menuRes) {
            this.menuRes = menuRes;
        }

        @Override
        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            actionMode.getMenuInflater().inflate(menuRes, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(final ActionMode actionMode, MenuItem menuItem) {
            final SparseBooleanArray selectedIds = adapter.getAllSelections().clone();
            switch (menuItem.getItemId()){
                case R.id.cab_delete:
                    adapter.deleteNotes(notes, selectedIds, true);
                    Snackbar deleteSnackBar = Snackbar.make(recyclerView, R.string.info_selected_binned, Snackbar.LENGTH_LONG);
                    deleteSnackBar.setAction(R.string.info_undo, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            adapter.restoreNotes(notes, selectedIds, true);
                        }
                    });
                    deleteSnackBar.show();
                    actionMode.finish();
                    return true;
                case R.id.cab_restore:
                    adapter.restoreNotes(notes, selectedIds, false);
                    Snackbar restoreSnackBar = Snackbar.make(recyclerView, R.string.info_selected_restored, Snackbar.LENGTH_LONG);
                    restoreSnackBar.setAction(R.string.info_undo, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            adapter.deleteNotes(notes, selectedIds, false);
                        }
                    });
                    restoreSnackBar.show();
                    actionMode.finish();
//                    if(notes.size()-1==0){refreshFragment();}
                    return true;
                case R.id.cab_pdelete:
                    final AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
                    alertBuilder.setMessage("Delete selected items?");
                    alertBuilder.setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int j) {
                            adapter.deleteNotes(notes, selectedIds, true);
                            Snackbar deletePermSnackBar = Snackbar.make(recyclerView, R.string.info_selected_deleted, Snackbar.LENGTH_LONG);
                            deletePermSnackBar.show();
                        }
                    });
                    alertBuilder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
                    alertBuilder.show();
                    actionMode.finish();
                    return true;
                case R.id.cab_palette:
                    final String[] colorsArray = getActivity().getResources().getStringArray(R.array.color_palette);
                    ColorPaletteDialog colorPaletteDialog = new ColorPaletteDialog();
                    colorPaletteDialog.show(getFragmentManager(), "color");
                    colorPaletteDialog.setListener(new ColorPaletteDialog.OnColorPickListener() {
                        @Override
                        public void onColorPick(int position) {
                            for(int i = (selectedIds.size()-1); i >= 0; i--){
                                if(selectedIds.valueAt(i)){
                                    Note color_note = notes.get(selectedIds.keyAt(i));
                                    color_note.setColor(colorsArray[position]);
                                    dbHandler.changeNoteColor(color_note);
                                    notes.set(selectedIds.keyAt(i), color_note);
                                }
                            }
                            adapter.notifyDataSetChanged();
                            actionMode.finish();
                        }
                    });
                    return true;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode actionMode) {
            adapter.removeSelection();
            stopActionMode();
            adapter.notifyDataSetChanged();
        }
    }
}
