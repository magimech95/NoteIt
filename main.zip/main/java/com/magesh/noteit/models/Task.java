package com.magesh.noteit.models;

import java.io.Serializable;

public class Task implements Serializable{
    private int _id;
    private int taskId;
    private String task;
    private boolean checked;

    public Task() {
    }

    public Task(int taskId, String task, boolean checked, int _id) {
        this.taskId = taskId;
        this.task = task;
        this.checked = checked;
        this._id = _id;
    }

    public Task(int _id) {
        this._id = _id;
    }

    public Task(String task, boolean checked) {
        this.task = task;
        this.checked = checked;
    }

    public int getId() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }
}
