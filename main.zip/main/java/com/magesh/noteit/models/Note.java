package com.magesh.noteit.models;

public class Note {
    int _id;
    String title;
    String note;
    int status;
    String color;
    long created_at;
    long last_modified_at;

    public Note() {
    }

    public Note(int _id, String title, String note, int status, String color, long created_at, long last_modified_at) {
        this._id = _id;
        this.title = title;
        this.note = note;
        this.status = status;
        this.color = color;
        this.created_at = created_at;
        this.last_modified_at = last_modified_at;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public long getCreated_at() {
        return created_at;
    }

    public void setCreated_at(long created_at) {
        this.created_at = created_at;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public long getLast_modified_at() {
        return last_modified_at;
    }

    public void setLast_modified_at(long last_modified_at) {
        this.last_modified_at = last_modified_at;
    }
}
