package com.magesh.noteit.database;

import android.database.sqlite.SQLiteDatabase;

public class NotesTable {
    //Database table name
    public static final String TABLE_NOTES = "notes";
    //Table column names
    public static final String NOTES_ID = "_id";
    public static final String NOTES_TITLE = "title";
    public static final String NOTES_NOTE = "note";
    public static final String NOTES_STATUS = "status";
    public static final String NOTES_COLOR = "color";
    public static final String NOTES_CREATED_AT = "created_at";
    public static final String NOTES_LAST_MODIFIED_AT = "last_modified_at";
    //Status
    public static final int STATUS_DELETED_TRUE = 0;
    public static final int STATUS_DELETED_FALSE = 1;
    //All projections
    public static final String[] PROJECTIONS_ALL = {
            NOTES_ID,
            NOTES_TITLE,
            NOTES_NOTE,
            NOTES_STATUS,
            NOTES_COLOR,
            NOTES_CREATED_AT,
            NOTES_LAST_MODIFIED_AT
    };
    //Default sort
    public static final String SORT_ORDER_DEFAULT = NOTES_ID + " DESC";
    //Table creation query
    private static final String CREATE_NOTES_TABLE = "CREATE TABLE "
            + TABLE_NOTES + " ( "
            + NOTES_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + NOTES_TITLE + " TEXT,"
            + NOTES_NOTE + " TEXT, "
            + NOTES_STATUS + " INTEGER, "
            + NOTES_COLOR + " TEXT DEFAULT '#FFFFFF', "
            + NOTES_CREATED_AT + " INTEGER, "
            + NOTES_LAST_MODIFIED_AT + " INTEGER);";

    //Create table
    public static void onCreate(SQLiteDatabase database){
        database.execSQL(CREATE_NOTES_TABLE);
    }

    //Upgrade table
    public static void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion){
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);
        onCreate(database);
    }
}
