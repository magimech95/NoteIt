package com.magesh.noteit.database;

import android.database.sqlite.SQLiteDatabase;

public class TasksTable {
    //Database table name
    public static final String TABLE_TASKS = "tasks";
    //Table column names
    public static final String TASKS_ID = "_id";
    public static final String TASKS_UID = "taskId";
    public static final String TASKS_LIST = "task";
    public static final String TASKS_STATUS = "checked";
    //All projections
    public static final String[] PROJECTIONS_ALL = {
            TASKS_ID,
            TASKS_UID,
            TASKS_LIST,
            TASKS_STATUS
    };
    //Default sort
    public static final String SORT_ORDER_DEFAULT = TASKS_ID;
    //Table creation query
    private static final String CREATE_NOTES_TABLE = "CREATE TABLE "
            + TABLE_TASKS + " ( "
            + TASKS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TASKS_UID + " INTEGER,"
            + TASKS_LIST + " TEXT, "
            + TASKS_STATUS + " INTEGER);";

    //Create table
    public static void onCreate(SQLiteDatabase database){
        database.execSQL(CREATE_NOTES_TABLE);
    }

    //Upgrade table
    public static void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion){
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        onCreate(database);
    }
}
