package com.magesh.noteit;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.magesh.noteit.models.Note;

import java.util.List;

public class DataAdapter  extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private Context context;
    private List<Note> data;
    private SparseBooleanArray selectedIds;

    public DataAdapter(List<Note> data) {
        this.data = data;
        selectedIds = new SparseBooleanArray();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView noteTitle;
        TextView noteContent;
        public ViewHolder(View itemView) {
            super(itemView);
            noteTitle = (TextView) itemView.findViewById(R.id.note_title);
            noteContent = (TextView) itemView.findViewById(R.id.note_content);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        context = parent.getContext();
        View v = LayoutInflater.from(context).inflate(R.layout.card_view, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Note note = data.get(position);
        holder.noteTitle.setText(note.getTitle());
        holder.noteContent.setText(note.getNote());
        if(selectedIds.get(position)) {
            ((CardView) holder.itemView).setCardBackgroundColor(ContextCompat.getColor(context, R.color.primary_light));
        } else {
            int color = (note.getColor()!=null) ? Color.parseColor(note.getColor()) : Color.WHITE;
            ((CardView) holder.itemView).setCardBackgroundColor(color);
        }

    }

    @Override
    public int getItemCount() {
        return (data != null) ? data.size() : 0;
    }

    //methods for action mode
    public void toggleSelection(int position){
        selectView(position, !selectedIds.get(position));
    }

    public void selectView(int position, boolean value){
        if(value){
            selectedIds.put(position, true);
        } else {
            selectedIds.delete(position);
        }
        notifyDataSetChanged();
    }

    public void selectAll(){
        for(int i=0; i<data.size(); i++){
            selectedIds.put(i, true);
        }
        notifyDataSetChanged();
    }

    public SparseBooleanArray getSelectedIds() {
        return selectedIds;
    }

    public int getSelectedCount() {
        return selectedIds.size();
    }

    public void removeSelection(){
        selectedIds.clear();
        notifyDataSetChanged();
    }
}
