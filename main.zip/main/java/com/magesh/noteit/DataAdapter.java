package com.magesh.noteit;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.magesh.noteit.database.TasksContentProvider;
import com.magesh.noteit.database.TasksTable;
import com.magesh.noteit.models.Note;

import java.util.List;

public class DataAdapter  extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    public static final int MAX_LINES_NOTES = 4;
    public static final int MAX_LINES_TASKS = 6;
    private Context context;
    private List<Note> data;
    private SparseBooleanArray selectedIds;

    public DataAdapter(List<Note> data) {
        this.data = data;
        selectedIds = new SparseBooleanArray();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView noteTitle;
        TextView noteContent;
        public ViewHolder(View itemView) {
            super(itemView);
            noteTitle = (TextView) itemView.findViewById(R.id.note_title);
            noteContent = (TextView) itemView.findViewById(R.id.note_content);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        context = parent.getContext();
        View v = LayoutInflater.from(context).inflate(R.layout.card_view, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Note note = data.get(position);
        holder.noteTitle.setText(note.getTitle());
        String noteText = note.getNote();
        if(noteText.equals(context.getPackageName())){
            noteText = "";
            Cursor cursor = context.getContentResolver().query(
                    TasksContentProvider.CONTENT_URI,
                    TasksTable.PROJECTIONS_ALL,
                    TasksTable.TASKS_UID + " = ?",
                    new String[]{String.valueOf(note.getId())},
                    TasksTable.SORT_ORDER_DEFAULT
            );
            if(cursor != null && cursor.getCount() > 0){
                while (cursor.moveToNext()){
                    if(cursor.getInt(cursor.getColumnIndex(TasksTable.TASKS_STATUS)) != 0){
                        noteText += "&#9745; " + cursor.getString(cursor.getColumnIndex(TasksTable.TASKS_LIST)) + "<br/>";
                    } else {
                        noteText += "&#9744; " + cursor.getString(cursor.getColumnIndex(TasksTable.TASKS_LIST)) + "<br/>";
                    }
                }
                holder.noteContent.setMaxLines(cursor.getCount() >  MAX_LINES_TASKS ? MAX_LINES_TASKS : cursor.getCount());
                cursor.close();
            }
            Spanned htmlString = Html.fromHtml(noteText);
            holder.noteContent.setText(htmlString);
            holder.noteContent.setTextSize(20);
        } else {
            holder.noteContent.setText(noteText);
            if(TextViewCompat.getMaxLines(holder.noteContent) > MAX_LINES_NOTES){
                holder.noteContent.setMaxLines(MAX_LINES_TASKS);
            }
        }
        if(selectedIds.get(position)) {
            ((CardView) holder.itemView).setCardBackgroundColor(ContextCompat.getColor(context, R.color.primary_light));
        } else {
            int color = (note.getColor()!=null) ? Color.parseColor(note.getColor()) : Color.WHITE;
            ((CardView) holder.itemView).setCardBackgroundColor(color);
        }

    }

    @Override
    public int getItemCount() {
        return (data != null) ? data.size() : 0;
    }

    //methods for action mode
    public void toggleSelection(int position){
        selectView(position, !selectedIds.get(position));
    }

    public void selectView(int position, boolean value){
        if(value){
            selectedIds.put(position, true);
        } else {
            selectedIds.delete(position);
        }
        notifyDataSetChanged();
    }

    public void selectAll(){
        for(int i=0; i<data.size(); i++){
            selectedIds.put(i, true);
        }
        notifyDataSetChanged();
    }

    public SparseBooleanArray getSelectedIds() {
        return selectedIds;
    }

    public int getSelectedCount() {
        return selectedIds.size();
    }

    public void removeSelection(){
        selectedIds.clear();
        notifyDataSetChanged();
    }
}
