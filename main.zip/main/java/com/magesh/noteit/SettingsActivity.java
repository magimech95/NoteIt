package com.magesh.noteit;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.Arrays;

public class SettingsActivity extends AppCompatActivity {
    public static final String INIT_COLOR_VALUE = "#FFFFFF";
    private static final String TAG = "SettingsActivity : ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        setupActionBar();
        getFragmentManager().beginTransaction()
                .replace(R.id.activity_settings_frame, new GeneralPreferencesFragment())
                .commit();
    }

    private void setupActionBar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.activity_settings_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        getSupportFragmentManager();
    }

    public static class GeneralPreferencesFragment extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener {
        public static final String PREF_DEFAULT_COLOR = "note_default_color";
        private SharedPreferences sharedPreferences;
        String[] colorsArray;
        String[] colorsArrayNames;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.preferences);
            colorsArray = getActivity().getResources().getStringArray(R.array.color_palette);
            colorsArrayNames = getActivity().getResources().getStringArray(R.array.color_palette_titles);
            sharedPreferences = getPreferenceScreen().getSharedPreferences();
            Preference colorPreference = findPreference(PREF_DEFAULT_COLOR);
            sharedPreferences.registerOnSharedPreferenceChangeListener(this);
            onSharedPreferenceChanged(sharedPreferences, PREF_DEFAULT_COLOR);
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            Preference preference = findPreference(key);
            String stringValue = sharedPreferences.getString(key, INIT_COLOR_VALUE);
             if (key.equals(GeneralPreferencesFragment.PREF_DEFAULT_COLOR)) {
                 int position = Arrays.asList(colorsArray).indexOf(stringValue);
                 preference.setSummary(colorsArrayNames[position]);
            }
        }
    }
}
