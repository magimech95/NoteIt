package com.magesh.noteit.models;

public class Note {
    int _id;
    String title;
    String note;
    int status;
    long created_at;


    public Note() {
    }

    public Note(String title, int _id, String note, int status, long created_at) {
        this.title = title;
        this._id = _id;
        this.note = note;
        this.status = status;
        this.created_at = created_at;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public long getCreated_at() {
        return created_at;
    }

    public void setCreated_at(long created_at) {
        this.created_at = created_at;
    }
}
