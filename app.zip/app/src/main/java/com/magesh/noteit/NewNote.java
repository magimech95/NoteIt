package com.magesh.noteit;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.magesh.noteit.db.DbHandler;
import com.magesh.noteit.models.Note;

import java.util.List;

public class NewNote extends AppCompatActivity {
    private Toolbar toolbar;
    private EditText note_title;
    private EditText note;
    private Note update_note;
    private DbHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_note);
        toolbar = (Toolbar) findViewById(R.id.new_note_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        dbHandler = new DbHandler(this);

        Intent intent=this.getIntent();
        if(intent.hasExtra("ID")){
            Bundle extras = getIntent().getExtras();
            update_note = new Note();
            update_note.set_id(extras.getInt("ID"));
            update_note.setTitle(extras.getString("TITLE"));
            update_note.setNote(extras.getString("NOTE"));
            note_title = (EditText) findViewById(R.id.new_note_title);
            note = (EditText) findViewById(R.id.new_note_content);
            note_title.setText(extras.getString("TITLE"));
            note.setText(extras.getString("NOTE"));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.new_note, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.note_delete){
            if(update_note!=null){
                dbHandler = new DbHandler(this);
                dbHandler.deleteNote(update_note);
            }
            NavUtils.navigateUpFromSameTask(this);
        }
        return super.onOptionsItemSelected(item);
    }

    public void saveNote(View view){

        note_title = (EditText) findViewById(R.id.new_note_title);
        note = (EditText) findViewById(R.id.new_note_content);

        if(update_note!=null){
            update_note.setTitle(note_title.getText().toString());
            update_note.setNote(note.getText().toString());
            dbHandler = new DbHandler(this);
            dbHandler.updateNote(update_note);
        }
        else {
            Note new_note = new Note();
            new_note.setTitle(note_title.getText().toString());
            new_note.setNote(note.getText().toString());
            new_note.setStatus(1);
            new_note.setCreated_at(System.currentTimeMillis());
            dbHandler = new DbHandler(this);
            dbHandler.addNote(new_note);
        }

        NavUtils.navigateUpFromSameTask(this);
    }
}
